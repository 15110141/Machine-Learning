# To support both python 2 and python 3
#Trước tiên, chúng ta cần khai báo các thư viện cần dùng. 
#Chúng ta cần numpy và matplotlib như trong bài Linear Regression cho việc tính toán ma trận và hiển thị dữ liệu. 
#Chúng ta cũng cần thêm thư viện scipy.spatial.distance để tính khoảng cách giữa các cặp điểm trong hai tập hợp một cách hiệu quả.
from __future__ import division, print_function, unicode_literals
import math
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(4)
#Tạo dữ liệu bằng cách lấy các điểm theo phân phối chuẩn có kỳ vọng tại các điểm có tọa độ 
#(-1, -1), (1, -1) và (0, 1), ma trận hiệp phương sai giống nhau và là ma trận đơn vị. 
#Mỗi cluster có 500 điểm. (Chú ý rằng mỗi điểm dữ liệu là một hàng của ma trận dữ liệu.
means = [[-1, -1], [1, -1], [0, 1]]
cov = [[1, 0], [0, 1]]
N = 20
X0 = np.random.multivariate_normal(means[0], cov, N) 
X1 = np.random.multivariate_normal(means[1], cov, N) 
X2 = np.random.multivariate_normal(means[2], cov, N) 

X = np.concatenate((X0, X1, X2), axis=0)
K = 3

original_label = np.asarray([0] * N + [1] * N + [2] * N).T
#Hiển thị dữ liệu trên đồ thị
#Chúng ta cần một hàm kmeans_display để hiển thị dữ liệu. Sau đó hiển thị dữ liệu theo nhãn ban đầu.

def kmeans_display(X, label):
    K = np.amax(label) + 1
    X0 = X[label == 0, :]
    X1 = X[label == 1, :]
    X2 = X[label == 2, :]

    plt.plot(X0[:, 0], X0[:, 1], 'b^', markersize=6, alpha=.8)
    plt.plot(X1[:, 0], X1[:, 1], 'go', markersize=6, alpha=.8)
    plt.plot(X2[:, 0], X2[:, 1], 'rs', markersize=6, alpha=.8)

    #     plt.axis('equal')
    plt.plot()


#     plt.show()

kmeans_display(X, original_label)
plt.show()
y = original_label.T
X = X.T