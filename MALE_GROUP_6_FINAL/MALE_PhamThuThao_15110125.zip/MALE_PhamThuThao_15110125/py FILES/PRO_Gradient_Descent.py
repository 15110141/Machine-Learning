# To support both python 2 and python 3
from __future__ import division, print_function, unicode_literals
import math
import numpy as np
import matplotlib.pyplot as plt
# grad để tính đạo hàm
def grad(x):
    return 2*x+ 5*np.cos(x)
# cost để tính giá trị của hàm số
def cost(x):
    return x**2 + 5*np.sin(x)
# myGD1 là phần chính thực hiện thuật toán Gradient Desent . Đầu vào của hàm số này là learning rate và điểm bắt đầu
def myGD1(eta, x0):
    x = [x0]
    for it in range(100):
        x_new = x[-1] - eta*grad(x[-1])
        if abs(grad(x_new)) < 1e-3:
            break
        x.append(x_new)
    return (x, it)
#  tìm nghiệm với các điểm khởi tạo khác nhau là x = 5 và x = -5
(x1, it1) = myGD1(.1, -5)
(x2, it2) = myGD1(.1, 5)
# In kết quả nghiệm tìm được
print('Solution x1 = %f, cost = %f, obtained after %d iterations'%(x1[-1], cost(x1[-1]), it1))
print('Solution x2 = %f, cost = %f, obtained after %d iterations'%(x2[-1], cost(x2[-1]), it2))