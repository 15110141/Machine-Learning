import numpy as np
from sklearn import svm, datasets #đây là thư viện để use tập data bên dưới
import matplotlib.pyplot as plt

def getData():
    # Get iris data from datasets (iris là giống hoa)
    iris = datasets.load_iris()

    return iris

# hàm xử lý vẽ đồ thị trong không gian 2 chiều
def get2DPlot(iris):
    X = iris.data[:, :2]  #  Lấy hai thuộc tính: độ rộng và chiều cao
    Y = iris.target
    X_min, X_max = X[:, 0].min() - .5, X[:, 0].max() + .5
    Y_min, Y_max = X[:, 1].min() - .5, X[:, 1].max() + .5
    plt.figure(2, figsize=(8, 6))
    plt.clf()

 # Biểu diễn tập dữ liệu huấn luyện bằng biểu đồ
    plt.scatter(X[:, 0], X[:, 1], c=Y, cmap=plt.cm.Paired)
    plt.xlabel('Sepal length')
    plt.ylabel('Sepal width')

    plt.xlim(X_min, X_max)
    plt.ylim(Y_min, Y_max)
    plt.xticks(())
    plt.yticks(())
    plt.show()

    """    những kernal mà ta dùng:
    SVC with linear kernel
    LinearSVC (linear kernel
    SVC with RBF kernel
    SVC with polynomial (degree 3) kernel
    """

def getSVMPlot(iris):
    X = iris.data[:, :2] # lấy hai thuộc tính đầu tiên của tập dữ liệu để tiện quan sát bằng đồ thị hai chiều
    
    y = iris.target

    h = .01  # hiệu chỉnh độ mỏng của lưới tọa độ trên đồ thị. Càng nhỏ thì càng sắc nét

# ta tạo 1 trường hợp của SVM và phù hợp data.

    # Không mở rộng qy mô data, vì ta muốn vẽ các support vector
    C = 1.0  # SVM regularization parameter
    svc = svm.SVC(kernel='linear', C=C).fit(X, y)
    rbf_svc = svm.SVC(kernel='rbf', gamma=0.7, C=C).fit(X, y)
    poly_svc = svm.SVC(kernel='poly', degree=2, C=C).fit(X, y)
    lin_svc = svm.LinearSVC(C=C).fit(X, y)

    # tạo lưới plots
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))

    # tạo tiêu đề (nhãn) cho plots
    titles = ['SVM with linear kernel',
              'LinearSVC (linear kernel)',
              'SVM with RBF kernel',
              'SVM with polynomial (degree 2) kernel']

    for i, clf in enumerate((svc, lin_svc, rbf_svc, poly_svc)):
        # vẽ ranh giới quyết định. để làm đc điều đó, ta tô màu cho mỗi điểm trong lưới
        plt.subplot(2, 2, i + 1)
        plt.subplots_adjust(wspace=0.4, hspace=0.4)

        Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])

        # cho kết quả vào ô màu
        Z = Z.reshape(xx.shape)
        plt.contourf(xx, yy, Z, cmap=plt.cm.coolwarm, alpha=0.8)

        # ô cũng là điểm tập huấn
        plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.coolwarm)
        plt.xlabel('Sepal length')
        plt.ylabel('Sepal width')
        plt.xlim(xx.min(), xx.max())
        plt.ylim(yy.min(), yy.max())
        plt.xticks(())
        plt.yticks(())
        plt.title(titles[i])

    plt.show()

if __name__ == "__main__":
    iris = getData()
    if iris is not None:
        getSVMPlot(iris)