from collections import defaultdict, Counter
from sklearn.metrics import accuracy_score
import pickle
"""
        tạo 1 lớp riêng biệt đại diện cho những lá của cây quyết định (decision tree)
        ta có thể xem đây như 1 classifer luôn trả về 1 giá gti giống nhau
        """
class DecisionTreeLeaf(object):

    def __init__(self, value):
# tạo 1 lá cây quyết dịnh mới, lá này đc ĐN bởi gtri trả về
        self.value = value

    def predict(self, x):
        """
        Phân loại cá thể. Khi mà lá này là LÁ NODE thì chúng luôn trả về cùng gtri.
        """
        return self.value

    def print_tree(self, indent):
        """
        In cây quyết định. (in gtri đầu ra)
        """
        spaces = ' '*indent
        print('{0} ==> {1}'.format(spaces, self.value))

#tạo lớp đại diện cho 1 nhánh (branch) trong cây
class DecisionTreeBranch(object):

    def __init__(self, feature_name, subtrees, default_value):
        """
        tạo nhánh cây quyết dịnh mới. mỗi nhánh đc đặc tả bởi chức năng mà nó kiểm  tra
         và các subtrees (nhánh follow theo nó ă) sẽ đc tiến hành tùy thuộc vào giá trị của
          chức năng của nó. cũng có 1 gtri mặc định, cái mả đc trả  về nếu gtri chưa thấy trc đó
          của tính năng bị gặp phải.
        """
        self.feature_name = feature_name
        self.subtrees = subtrees
        self.default_value = default_value

    def predict(self, x):
        """
        phân chia cá thể. ta nhìn vào tính năng của nhánh này, và chọn subtree phụ thuộc vào
        gtri của tính năng. nếu gtri chưa đc thấy trc đó, thì trả về gtri mặc định
        """
        subtree = self.subtrees.get(x[self.feature_name])
        if subtree:
            return subtree.predict(x)
        else:
            return self.default_value

    def print_tree(self, indent):
        """
       dùng đệ quy in cây quyết định
        """
        spaces = ' '*indent
        print('{0}{1}:'.format(spaces, self.feature_name))
        print('{0}  <default> ==> {1}'.format(spaces, self.default_value))
        for v in sorted(self.subtrees):
            print('{0}  {1} ->'.format(spaces, v))
            self.subtrees[v].print_tree(indent + 4)

# hàm đệ quy này sẽ trả về 1 lá cây quyết định hoặc nhánh cây nơi mà subtrees đc tính đệ quy trc đó
def train_decision_tree(XY, available_features):
    # đầu tiên ta ktra giá trị đầu ra thường xuyên khi train là gì
    distribution = Counter(y for _, y in XY)
    majority_value = distribution.most_common(1)[0][0]
    """
           đầu tiên là 2 trường hợp cơ bản trong đệ quy: train hoàn toàn đồng nhất hoặc rời khỏi tính năng
           sau đó ta cần trả về 1 lá.

           nếu các trường hợp trả về cùng gtri, thì trả lá về vs giá trị này
            """
    if len(distribution) == 1:
        return DecisionTreeLeaf(majority_value)

    # nếu đã qua hết tất cả các chức năng thì trả về lá vs gtri chiếm đa số
    if not available_features:
        return DecisionTreeLeaf(majority_value)

    # chọn tính năng có lợi nhất. để sắp xếp tính hữu dụng cho các chức năng,
    # ta dùng hàm majority_sum_scorer, sẽ đc định nghĩa bên dưới
    selected_feature = max(available_features,
                           key=lambda f: majority_sum_scorer(f, XY))

    # Các tính năng sẽ có sẵn khi xây dựng các subtrees.
    next_available_features = set(available_features) - set([selected_feature])

    # chia nhóm train thành các nhóm con, dựa trên các gtri khác nhau của các tính năng đc chọn
    XY_split = split_by_feature(selected_feature, XY)

    # xây dựng subtrees bằng cách gọi đệ quy. mỗi subtree đc liên kết với 1 gtri của tính năng
    subtrees = {}
    for value, XY_subset in XY_split.items():
        subtrees[value] = train_decision_tree(XY_subset,
                                              next_available_features)

    # trả về 1 cây quyết định chứa kết quả.
    return DecisionTreeBranch(selected_feature, subtrees, majority_value)


def split_by_feature(feature_name, XY):
    """
    chia nhóm train thành các nhóm con, dựa trên các gtri khác nhau của các tính năng đc chọn
    """
    XY_split = defaultdict(list)
    for x, y in XY:
        XY_split[x.get(feature_name)].append((x, y))
    return XY_split


def majority_sum_scorer(feature_name, XY):
    """
    tính toán những tính hữu ích của tính năng
    ý tưởng :
    (1) chia nhóm train thành các nhóm con, dựa trên các gtri khác nhau của các tính năng đc chọn
    (2) trong mỗi nhóm, xét mức độ phổ biến của class đó.

Lý do cho quy tắc này là nếu tính năng được cấp cho 1 cách phân chia tốt, thì mỗi nhóm là đồng nhất
(nghĩa là nhóm chiếm đa số)
    """
    distributions = defaultdict(Counter)
    majority_sum = 0
    for distribution in distributions.values():
        majority_sum += distribution.most_common(1)[0][1]
    return majority_sum

class DecisionTree(object):

    def __init__(self):
        pass

    def fit(self, X, Y):
        XY = list(zip(X, Y))
        available_features = set(f for x in X for f in x)
        self.root = train_decision_tree(XY, available_features)

    def predict(self, X):
        return [self.predict_one(x) for x in X]

    def predict_one(self, x):
        return self.root.predict(x)

    def print_tree(self):
        return self.root.print_tree(0)

# training set: the features
X = [{'city':'Gothenburg', 'month':'July'},
     {'city':'Gothenburg', 'month':'December'},
     {'city':'Paris', 'month':'July'},
     {'city':'Paris', 'month':'December'}]

# training set: the gold-standard outputs
Y = ['rain', 'rain', 'sun', 'rain']

classifier = DecisionTree()
classifier.fit(X, Y)

classifier.print_tree()

Xtest = [{'city':'Gothenburg', 'month':'June'},
         {'city':'Gothenburg', 'month':'November'},
         {'city':'Paris', 'month':'June'},
         {'city':'Paris', 'month':'November'}]

Ytest = ['rain', 'rain', 'sun', 'rain']

guesses = classifier.predict(Xtest)

print(guesses)
accuracy_score(Ytest, guesses)