import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model, datasets

hours=np.array([0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 1.75, 2.00, 2.25, 2.50, 2.75, 3.00, 3.25, 3.50, 4.00,
                4.25, 4.50, 4.75, 5.00, 5.50])
hours=hours.reshape(20,1)
Exam_pass=np.array([0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1])
#print(hours, "\n",Exam_pass)
# run the classifier

logistic = linear_model.LogisticRegression(C=1e5)
logistic.fit(hours, Exam_pass)

print('Coefficients: \n', logistic.coef_, '\nIntercept: \n',logistic.intercept_)
# plot the result
plt.figure(1, figsize=(8, 6))
plt.clf()
plt.scatter(hours.ravel(), Exam_pass, color='black', zorder=20)

# plot sigmoid fit
def model(x):
    return 1 / (1 + np.exp(-x))
loss = model(hours * logistic.coef_ + logistic.intercept_).ravel()
plt.plot(hours, loss, color='red', linewidth=3)

# plt.plot(hours, 1 / (1 + np.exp(-1*(hours * logistic.coef_ + logistic.intercept_))),color='red', linewidth=3)
# compare to ordinary linear model
ols = linear_model.LinearRegression()
ols.fit(hours, Exam_pass)
plt.plot(hours, ols.coef_ * hours + ols.intercept_, linewidth=1)
plt.axhline(.5, color='.5')

plt.ylabel('P(PassExam)')
plt.xlabel('Hours')
plt.xticks(range(0, 6))
plt.yticks([0, 0.5, 1])
plt.ylim(-.25, 1.25)
plt.xlim(-1, 6)
plt.legend(('Logistic Regression Model', 'Linear Regression Model'),
           loc="lower right", fontsize='small')
plt.show()